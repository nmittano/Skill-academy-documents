CREATE OR REPLACE PACKAGE XX2_GL_DATA_ENTRY IS
	PROCEDURE LOAD_DATA is
		V_JE_SOURCE_NAME VARCHAR(20);
		utl_dir VARCHAR2(100):='/u01/clone/BRZL/apps/apps_st/appl/au/12.0.0/bin';
		v_getline VARCHAR2(1000);
	BEGIN
		v_inhandle:= utl_file.fopen(utl_dir,'XX2_J_DATA.dat','R');
		LOOP
			BEGIN
				UTL_FILE.GET_LINE(v_inhandle,v_getline);
			EXCEPTION	
			WHEN no_data_found THEN
				FND_FILE.PUT_FILE(fnd_file.LOG,'No data Found');
				EXIT;
			END;
			
				

		
	PROCEDURE VALIDATE_DATA;



	PROCEDURE START_ENTRY(ERRBUF OUT VARCHAR2, RETCODE OUT NUMBER)
		LOAD_DATA;
		VALIDATE_DATA;
	END START_ENTRY;

END XX2_GL_DATA_ENTRY;
/




CREATE OR REPLACE PACKAGE BODY XX2_DATA_VALIDATION IS
	
	PROCEDURE VALIDATE_DATA IS 
		V_JE_SOURCE_NAME 	varchar(20);
		V_NAME_COUNT		number;
		VALID_REC		VARCHAR2(1) := 'Y';
		CURSOR c_cust_j_tbl IS SELECT * FROM appsread.CUSTOM_JOURNAL_TBL;
	BEGIN
		FOR v_cust_j_tbl IN c_cust_j_tbl 
		LOOP
			V_JE_SOURCE_NAME := v_cust_j_tbl.USER_JE_SOURCE_NAME;

			SELECT COUNT(*) INTO V_NAME_COUNT FROM appsread.XX2_GL_INT WHERE USER_JE_SOURCE_NAME =  V_JE_SOURCE_NAME;

			IF V_NAME_COUNT < 1 THEN
				VALID_REC := 'Y';
			ELSE
				VALID_REC := 'N';
				INSERT INTO appsread.ERROR_TBL VALUES('USER_JE_SOURCE_NAME','The value in this column must be unique',V_JE_SOURCE_NAME);
			END IF;

			IF v_cust_j_tbl.JE_SOURCE_KEY IS NULL THEN
				v_cust_j_tbl.je_source_key := V_JE_SOURCE_NAME;
			END IF;
			
			IF v_cust_j_tbl.OVERRIDE_EDITS_FLAG IS NULL THEN
				VALID_REC := 'N';
				INSERT INTO appsread.ERROR_TBL VALUES('OVERRIDE_EDITS_FLAG','The value in this column must not be NULL',V_JE_SOURCE_NAME);
				
			END IF;
			
			IF v_cust_j_tbl.EFFECTIVE_DATE_RULE_CODE IS NULL THEN
				VALID_REC := 'N';
				INSERT INTO appsread.ERROR_TBL VALUES('EFFECTIVE_DATE_RULE_CODE','The value in this column must not be NULL',V_JE_SOURCE_NAME);
			END IF;

			IF VALID_REC = 'Y' THEN
				INSERT INTO appsread.XX2_GL_INT VALUES( v_cust_j_tbl.USER_JE_SOURCE_NAME,
								v_cust_j_tbl.JE_SOURCE_KEY,
								v_cust_j_tbl.DESCRIPTION,
								v_cust_j_tbl.JOURNAL_REFERENCE_FLAG,
								v_cust_j_tbl.JOURNAL_APPROVAL_FLAG,
								v_cust_j_tbl.IMPORT_USING_KEY_FLAG,
								v_cust_j_tbl.OVERRIDE_EDITS_FLAG,
								v_cust_j_tbl.EFFECTIVE_DATE_RULE_CODE
								);
				FND_FILE.PUT_LINE(fnd_file.output, 'INSERTED RECORD: ' || chr(9) ||
								v_cust_j_tbl.USER_JE_SOURCE_NAME || ' ; ' ||
								v_cust_j_tbl.JE_SOURCE_KEY || ' ; ' ||
								v_cust_j_tbl.DESCRIPTION || ' ; ' ||
								v_cust_j_tbl.JOURNAL_REFERENCE_FLAG || ' ; ' ||
								v_cust_j_tbl.JOURNAL_APPROVAL_FLAG || ' ; ' ||
								v_cust_j_tbl.IMPORT_USING_KEY_FLAG || ' ; ' ||
								v_cust_j_tbl.OVERRIDE_EDITS_FLAG || ' ; ' ||
								v_cust_j_tbl.EFFECTIVE_DATE_RULE_CODE ); 
			ELSE
				DECLARE
					CURSOR c_err_tbl IS SELECT * FROM appsread.ERROR_TBL WHERE COLUMN_KEY = V_JE_SOURCE_NAME;
				BEGIN
					FOR v_err_tbl IN c_err_tbl 
					LOOP
						FND_FILE.PUT_LINE(fnd_file.log,'ERRORED COLUMN: ' || v_err_tbl.column_name || ', ERROR: ' || v_err_tbl.error_message);
					END LOOP;
				END;

				FND_FILE.PUT_LINE(fnd_file.log, 'REJECTED RECORD: ' || chr(9) ||
								v_cust_j_tbl.USER_JE_SOURCE_NAME || ' ; ' ||
								v_cust_j_tbl.JE_SOURCE_KEY || ' ; ' ||
								v_cust_j_tbl.DESCRIPTION || ' ; ' ||
								v_cust_j_tbl.JOURNAL_REFERENCE_FLAG || ' ; ' ||
								v_cust_j_tbl.JOURNAL_APPROVAL_FLAG || ' ; ' ||
								v_cust_j_tbl.IMPORT_USING_KEY_FLAG || ' ; ' ||
								v_cust_j_tbl.OVERRIDE_EDITS_FLAG || ' ; ' ||
								v_cust_j_tbl.EFFECTIVE_DATE_RULE_CODE ); 
			END IF;
			VALID_REC := 'Y';
		END LOOP;
	END VALIDATE_DATA;

	PROCEDURE START_VALIDATION(ERRBUF OUT VARCHAR2, RETCODE OUT NUMBER) IS
	BEGIN
		VALIDATE_DATA;
	END;

END XX2_DATA_VALIDATION;
	

	
			
			
	

				
	